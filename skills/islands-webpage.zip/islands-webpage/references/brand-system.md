# Islands Visual Brand System

The design half of the Islands brand, taken from Gabriel's design standards
(Figma "Islands Designs", the Homepage + landing-page approval board). Copy voice
lives in the `islands-brand-voice` skill and in SOUL.md; this file is how a page
should *look*. When these two ever disagree, prefer whatever the Figma board shows.

## The one-sentence version

Black and white, one warm orange accent, huge tight-tracked headlines, lots of
whitespace, real numbers. Editorial and confident, never busy or gradient-happy.
A page should feel like it costs money.

## Color

Use these exact tokens (they match the approved audit page and the homepage):

```
--bg:        #ffffff   /* default page background */
--bg-off:    #f6f5f2   /* alternating section background, warm off-white */
--ink:       #0a0a0a   /* near-black: text, dark sections, footer */
--ink-2:     #121212   /* second dark, for layering on dark sections */
--card:      #161615   /* card surface on dark */
--border:    #e6e4df   /* hairline borders on light */
--border-dk: #2a2926   /* hairline borders on dark */
--muted:     #6b6862   /* secondary text on light */
--muted-dk:  #a3a09a   /* secondary text on dark */
--orange:    #e0793d   /* THE accent. one accent, used sparingly */
--orange-2:  #ef8b4e   /* lighter stop for the headline gradient */
--orange-bg: rgba(224,121,61,0.12)  /* tint behind pills/callouts */
```

Rules:
- Orange is an accent, not a theme. It appears in: the second line of a hero
  headline (as a gradient), links, one-word emphasis, small pills, and primary
  button fills. If a section is more than ~10% orange, it is wrong.
- The headline gradient is `linear-gradient(90deg,var(--orange),var(--orange-2))`
  applied with `background-clip:text; color:transparent`.
- Never introduce a second accent hue (no blues, purples, teals). The only
  non-brand colors allowed are muted status tints already in the audit template
  (red/amber/green at 12% for "behind/on-par/ahead" style indicators).

## Type

- **One typeface: Inter** (Google Fonts), weights 400/500/600/700/800. It is what
  the approved audit ships and it is web-safe and hostable. Load it in `<head>`.
  (The homepage comp uses a custom display face for the giant hero words; we do
  not have a license/file for it, so Inter Extra-Bold is the standard stand-in.
  If Gabriel provides the display webfont, swap it in for hero headlines only.)
- Scale (desktop): hero headline 64-88px / weight 800 / letter-spacing -0.03em /
  line-height 1.02. Section headline 32-40px / 700 / -0.02em. Body 17-18px / 400 /
  line-height 1.6. Eyebrow (section kicker) 13px / 600 / uppercase / letter-spacing
  0.08em / orange. Big stat numbers 40-56px / 800.
- Headlines are tight (negative tracking). Body is roomy (1.6 line-height).
- **Never use em dashes** anywhere (house rule). Use commas, colons, periods, or
  split the sentence. Applies to every word on the page.

## Layout & rhythm

- Content column max-width ~1120px, centered, 48px side padding (24px on mobile).
- Section vertical padding 96-120px desktop, 64px mobile.
- Section-background rhythm: the audit's proven order is dark hero, then middle
  sections alternating white / off-white, then a dark closing section, with the
  top bar and footer dark to frame the two dark ends. A shorter page can be a
  dark hero, one or two light sections, dark footer.
- Generous whitespace is the brand. When unsure, add space, not elements.
- Corners: cards and buttons use ~14-16px radius. Pills are fully rounded.
- Borders are hairlines (1px) in the border tokens, never heavy.

## Components (from the homepage/audit system)

- **Header (top bar):** the Islands logo on the left (`assets/islands-logo.svg`,
  inline the SVG so the page stays self-contained; it inherits `color`, so it is
  black on light bars and white on dark ones). Optional right side: either simple
  nav text, a context label (like the audit's "AI Visibility Audit - Month Year"),
  or a single black/orange pill button ("Get in touch"). Header height ~88px.
- **Hero:** eyebrow (orange, uppercase) -> two-line headline where the second line
  is the orange gradient -> one or two sentence subhead in muted -> optional
  primary button. Dark background is the default hero treatment.
- **Stat row:** 2-4 big numbers in a row, each with a small caption under it and,
  where relevant, a tiny source line in muted. Numbers are the loudest thing on a
  light section.
- **Cards:** flat surface, hairline border, generous padding. On dark use `--card`
  + `--border-dk`; on light use white/off-white + `--border`. No drop shadows
  heavier than a whisper.
- **Buttons:** primary = orange fill, near-black text, rounded; or near-black fill,
  white text (the homepage "Get in touch" pill). Secondary = text + arrow. Always
  one clear primary action per section.
- **Footer:** dark. Small "Islands" mark or logo, one line of context, links in
  muted-dk. Mirrors the top bar.

## Logo usage

- File: `assets/islands-logo.svg` (also hosted at `islands-ai.com/assets/islands-logo.svg`).
  It is a single-color vector using `currentColor`, so set the parent's `color`
  to control it: `#0a0a0a` on light, `#f6f5f2` on dark. Never recolor it orange,
  never stretch it (keep the 128:40 aspect ratio), never add effects.
- Inline the SVG markup directly in the page so the file stays self-contained.
- Give it clear space; do not crowd it with nav items.

## Voice on the page (pointer)

Load the `islands-brand-voice` skill for the words. In short: declarative, verb-led,
concrete numbers, "operators not consultants," single clear CTA, founder-to-founder,
no hype and no filler. Every claim on a public page must be true and sourced.

## Quick self-check before publishing

- One accent color (orange), used sparingly. No stray hues.
- Inter everywhere. Headlines tight, body roomy. No em dashes.
- Logo is `currentColor`, correct color per background, undistorted.
- Real content only, nothing fabricated. Single primary CTA.
- Page is one self-contained HTML file (all CSS/SVG inlined, only Google Fonts +
  intended outbound links are external). Responsive down to ~380px.
