---
name: islands-webpage
description: >
  Build a single on-brand Islands webpage, OR take an already-made page or Claude
  artifact and rebrand it to the Islands guidelines, then publish it live to a
  path under islands-ai.com. Use whenever someone wants to stand up a webpage,
  landing page, one-pager, microsite, event page, or shareable page on the
  Islands domain, says "make a page for X and put it live", "publish this to
  islands-ai.com", "build a landing page for a company", OR wants an existing
  artifact rebranded and hosted on our domain instead of a claude.ai CDN link
  ("brand this artifact and put it on our domain", "reskin this to our brand",
  "make this artifact look like Islands and give me an islands-ai.com link").
  Produces one self-contained, brand-accurate HTML file (Islands colors, type,
  logo, voice) and pushes it to the islandsdev/islands-ai GitHub Pages repo so it
  goes live at a real URL you can send. For the specific SEO/AEO/GEO prospect
  audit, use the ai-visibility-audit skill instead; this is the general page
  builder and rebrander.
---

# Islands Webpage

Turn a request into a live, on-brand page at `https://islands-ai.com/<path>`.

## Two ways in

- **Build from scratch** — you have content or a brief, no page yet. Follow
  "Process (build from scratch)".
- **Rebrand an existing artifact** — you already have something (an HTML file, a
  claude.ai artifact link, or a PDF) and want its content wearing the Islands
  brand and living on our domain instead of a claude.ai CDN link or a raw file.
  Follow "Process (rebrand an existing artifact)".

Both paths end at the same non-negotiable: the published page conforms to the
Islands brand guidelines in `references/brand-system.md`, and both finish through
the same "Publishing" step. Rebranding is not optional cosmetic polish; a page
that does not meet the brand system does not ship.

## What this produces

One self-contained HTML file (all CSS, the logo SVG, and any images inlined; the
only external calls are Google Fonts and whatever links you intend), styled to the
Islands brand, published to the live domain. The deliverable you hand back is the
live `islands-ai.com/<path>` URL, not a loose file.

## Inputs to gather

1. **Purpose + content, OR the existing artifact**: either what the page is for
   and what goes on it (the real copy or raw material), or, for a rebrand, the
   artifact itself, in any of three forms:
   - an **HTML file** (read it directly),
   - a **claude.ai artifact link** (fetch its rendered HTML, e.g. WebFetch, so you
     are working from the real content, not a guess),
   - a **PDF** (extract its text, tables, and images first with the `pdf` skill,
     then treat that extracted content as the source).
   Landing page, event page, one-pager, microsite, a Claude artifact, or a PDF to
   turn into a hosted page.
2. **URL path**: where it lives under the domain. The house pattern is
   `slug/company` (e.g. `launch/acme`) but any lowercase, hyphenated path works
   (`acme`, `events/demo-day`). This is the "put it under our domain" choice the
   user makes. Ask for it if not given; suggest a sensible slug from the page's
   purpose.
   - Note on subdomains: true subdomains (`acme.islands-ai.com`) are NOT set up.
     The domain serves path-based URLs (`islands-ai.com/<path>`) via GitHub Pages.
     If someone truly needs a subdomain, that is a separate DNS + host change, not
     this skill. Default to a path and say so.
3. **Primary action**: the one thing the page should get the reader to do (book a
   call, sign up, reply, download). Every page has a single clear CTA. Islands'
   default booking link is `https://calendly.com/nick-islandshq/islands-ai-content-discovery`
   unless the user gives a different one.
4. **Any assets or links**: logos of a featured company, images (must be provided,
   never invented), real stats with sources.

## The rule that matters most: never invent

If the page is going out under the Islands name, everything on it has to be true.
No fabricated stats, fake quotes, invented logos, or made-up client names. If you
don't have real content for a section, drop the section rather than pad it. Sourced
numbers only.

## Process (build from scratch)

1. Read `references/brand-system.md` (colors, type, layout, components, logo rules)
   and load the `islands-brand-voice` skill for the words. These two together are
   the Islands brand; follow both.
2. Start from `assets/template.html`. It is the approved structure: dark top bar
   with the real logo, dark hero (two-line headline, second line orange), a light
   stat row, an off-white card grid, a dark closing pitch with the CTA, and a dark
   footer. Copy it and replace the bracketed placeholders. Keep the CSS token
   block, the section rhythm, and the inlined logo SVG. Add, remove, or reorder
   sections to fit the actual content; do not pad to fill the template.
3. Write the copy in Islands voice: declarative, concrete, verb-led, one clear
   CTA, no hype, no filler. No em dashes anywhere (house rule) — use commas,
   colons, periods, or split the sentence.
4. Keep it one self-contained file. Inline the logo (already in the template) and
   any images as data URIs or `islands-ai.com/assets/...` links. Do not add
   external scripts or stylesheets beyond Google Fonts.
5. Run the self-check at the bottom of `references/brand-system.md` (one accent,
   Inter, logo colored correctly per background, real content, single CTA,
   responsive to ~380px, no em dashes).
6. Save the finished HTML to a working file, then publish (below). Share the live
   URL.

## Process (rebrand an existing artifact)

The goal: the artifact keeps its substance and, where it earns it, its layout, but
it comes out looking unmistakably like Islands and lives on our domain. Conforming
to `references/brand-system.md` is mandatory, not a light coat of paint.

1. Read `references/brand-system.md` and load `islands-brand-voice` first, same as
   above. You are converting the artifact TO this system, so you need it in hand.
2. Get the real source, by type:
   - **HTML file**: read it.
   - **claude.ai artifact link**: try the **WebFetch tool on the link first**. In a
     session logged into claude.ai (the normal case), WebFetch resolves both
     `claude.ai/code/artifact/<uuid>` and `claude.ai/public/artifacts/<uuid>` via
     your login and returns the real HTML, saving the full document to a file. This
     works even for PRIVATE org artifacts you have access to: no public sharing, no
     browser, no paste. The returned HTML wraps the artifact in an injected
     `<!-- frame-runtime -->…<!-- /frame-runtime -->` `<script>` plus a small frame
     `<style>`; strip that preamble and rebrand the artifact's own markup (its
     `<title>`/`<style>`/`<body>` onward). Do NOT use curl for these links (curl
     gets the SPA shell or a 403).
     Fallbacks, in order, only if WebFetch is unavailable or fails: (a) for a public
     share link on a machine without WebFetch, run `scripts/fetch_artifact.mjs
     <link> out.html`, which drives an installed Chromium browser (Edge on Windows,
     Chrome/Chromium/Brave on Mac/Linux) headless over the DevTools Protocol and
     extracts the sandboxed frame, needs Node >= 21 and a browser, no npm/download,
     but a logged-out browser 404s a PRIVATE link, so it needs a public/shared one;
     (b) ask the user to download the artifact and hand you the `.html` file, which
     always works with zero dependencies. Never rebrand a shell you could not fully
     load; confirm you actually have the real content first.
   - **PDF**: use the `pdf` skill to extract text, tables, and images (OCR it first
     if scanned). Rebuild that content as a real HTML page; do not embed the PDF in
     an iframe and call it done. The output is a proper web page, not a PDF viewer.
     If the user also wants the original file downloadable, host it as a raw asset
     (see Publishing) and link to it from the page.
   Read the whole thing before changing anything: what it says, its structure, and
   what it depends on (fonts, CDN scripts, external images, live data).
3. Decide the depth of rebrand, and say which you are doing:
   - **Letterhead wrap** (default when the artifact's own layout is fine, e.g. a
     report, doc, or dashboard): keep its structure and content, but replace its
     styling with the Islands system, add the Islands top bar (inlined logo) and
     footer, and swap its palette/type to the brand tokens and Inter. It should
     read as an Islands document.
   - **Full redesign** (when the artifact is a marketing/landing page, or its look
     clashes with the brand): rebuild it into the Islands page system using
     `assets/template.html` as the shell, pouring the artifact's real content into
     brand sections.
   When unsure which, ask; both must still pass the brand self-check.
4. Apply the brand, concretely: strip the artifact's own color/type theme and
   replace every color with the brand tokens (one orange accent, no stray hues),
   set all type to Inter with the brand scale, add the top bar with the inlined
   `assets/islands-logo.svg` and the dark footer, and match section rhythm and
   spacing to the system. Remove em dashes from all copy.
5. Make it self-contained and hostable. Inline external assets: download and embed
   images as data URIs (or move them under `islands-ai.com/assets/`), inline any
   CSS, and replace CDN font links with the Google Fonts Inter link. Keep only
   Google Fonts and intended outbound links as external calls.
   - Interactive artifacts: static and lightly-interactive pages inline cleanly.
     A heavy live app (React runtime, external data fetches, auth) is a bigger job,
     the runtime and its data have to be handled, so flag that to the user rather
     than shipping something half-working. Never fake live data with a static
     snapshot without saying so.
6. Do not invent. Rebranding restyles; it does not add claims. Keep the artifact's
   real numbers and text; if something was a placeholder in the artifact, fix or
   drop it, do not invent a real-looking value.
7. Run the brand self-check at the bottom of `references/brand-system.md`. If it
   fails, it is not rebranded yet. Then save to a working file and publish (below).

## Publishing

The page is hosted on GitHub Pages (repo `islandsdev/islands-ai`) at
`https://islands-ai.com/<path>`. The repo lives at `/Users/ali/Documents/islands-ai`
and ships `publish-page.sh`, which copies your HTML to `<path>/index.html`, commits,
and pushes. GitHub Pages redeploys in about a minute.

```bash
/Users/ali/Documents/islands-ai/publish-page.sh <url-path> <path-to-your-page.html> "<commit message>"
```

- The script normalizes the path (lowercase, hyphens, slashes), clones the repo
  first if this is a fresh machine, skips the commit if nothing changed, refuses
  `audit/*` (reserved for the ai-visibility-audit skill), and prints the live URL.
- Re-running with the same `<url-path>` overwrites that page in place, so a revised
  version replaces the old one at the same link. Use a new path for a new page.
- If the working directory is missing entirely, clone
  `https://github.com/islandsdev/islands-ai.git` first.
- Hand the user the printed `https://islands-ai.com/<path>` link as the deliverable.

### Hosting a raw file (the "Islands CDN")

"Islands CDN" just means a real file served from our own domain instead of a
claude.ai CDN link. Same repo, same domain. To host a raw file (the original PDF
behind a rebranded page, an image, a downloadable), use `publish-asset.sh`, which
serves the file verbatim at the exact path (not wrapped as `index.html`):

```bash
/Users/ali/Documents/islands-ai/publish-asset.sh <url-path-with-extension> <file> "<commit message>"
```

For example `acme/brief.pdf <file>` serves it at `islands-ai.com/acme/brief.pdf`.
Shared reusable assets live under `assets/` (e.g. `islands-ai.com/assets/logo.svg`).
Use this for the "download the original" link on a rebranded PDF page, or any time
someone wants a file on our domain rather than a Claude or third-party link.

## What lives where

- The whole site (audits + general pages) is one GitHub Pages repo,
  `islandsdev/islands-ai`, custom domain `islands-ai.com` (HTTPS enforced). Root
  `/` redirects to islandshq.xyz. Audits are under `/audit/<company>`; general
  pages go wherever you publish them.
- Reusable brand assets are hosted at `islands-ai.com/assets/` (e.g.
  `islands-ai.com/assets/islands-logo.svg`), though the template inlines the logo
  so pages stay self-contained.

## Reference files

- `references/brand-system.md`: the Islands visual system — exact color tokens,
  type scale, layout rhythm, components, and logo rules. Read before building.
- `scripts/fetch_artifact.mjs`: FALLBACK for the "rebrand from a link" path when
  the WebFetch tool is unavailable and you only have a PUBLIC share link. Drives an
  already-installed Chromium browser (Edge/Chrome) headless over the DevTools
  Protocol and extracts the sandboxed artifact frame. Node >= 21, no npm install.
  Prefer WebFetch on the link first (it handles private org artifacts via login);
  this script needs a public link because a logged-out browser 404s a private one.
- `assets/template.html`: the approved page structure to copy and fill in.
- `assets/islands-logo.svg`: the Islands logo, single-color `currentColor` vector
  (already inlined in the template; here too if a page needs it standalone).
- `islands-brand-voice` skill (separate): the copy voice, vocabulary, proof
  points, and CTA links. Always load it for the words.
- `ai-visibility-audit` skill's `assets/template.html` (separate skill): a fuller,
  already-shipped worked example of the same brand system, a complete multi-section
  page (dark hero, stat band, card grid, citation chart, dark closing). Borrow its
  patterns for richer layouts. `assets/template.html` here is the lean starting
  point; that one shows the system at full length. Where they differ, this skill's
  `references/brand-system.md` is the source of truth.
