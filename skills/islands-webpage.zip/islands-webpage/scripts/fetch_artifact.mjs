#!/usr/bin/env node
// fetch_artifact.mjs — turn a claude.ai artifact link into its raw HTML.
//
// Claude artifacts are a JS single-page app whose real HTML renders inside a
// cross-origin sandboxed iframe (claudeusercontent.com). A plain fetch gets the
// empty shell. This drives a Chromium browser the machine ALREADY has (Edge on
// Windows, Chrome/Chromium/Brave on Mac/Linux) over the DevTools Protocol, lets
// the page run, snapshots ALL frames (MHTML), and extracts the artifact frame.
//
// No npm install, no browser download. Needs only Node >= 21 (built-in WebSocket)
// and any installed Chromium-family browser.
//
// Usage:  node fetch_artifact.mjs <artifact-url> [out.html]
//   prints the artifact HTML to stdout (or writes out.html if given).
// Exit codes: 0 ok · 2 no browser found · 3 render/timeout · 4 no HTML extracted.

import { spawn, execSync } from 'node:child_process';
import { existsSync, writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import http from 'node:http';

const url = process.argv[2];
const outFile = process.argv[3];
if (!url) { console.error('usage: node fetch_artifact.mjs <artifact-url> [out.html]'); process.exit(1); }
if (typeof WebSocket === 'undefined') {
  console.error('error: this Node lacks a built-in WebSocket (need Node >= 21). Update Node, or download the artifact and pass the .html file instead.');
  process.exit(3);
}

function findBrowser() {
  const plt = process.platform;
  const candidates = [];
  if (plt === 'win32') {
    const pf = process.env['PROGRAMFILES'] || 'C:\\Program Files';
    const pf86 = process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)';
    const la = process.env['LOCALAPPDATA'] || '';
    candidates.push(
      `${pf86}\\Microsoft\\Edge\\Application\\msedge.exe`,
      `${pf}\\Microsoft\\Edge\\Application\\msedge.exe`,
      `${pf}\\Google\\Chrome\\Application\\chrome.exe`,
      `${pf86}\\Google\\Chrome\\Application\\chrome.exe`,
      la && `${la}\\Google\\Chrome\\Application\\chrome.exe`,
      `${pf}\\BraveSoftware\\Brave-Browser\\Application\\brave.exe`,
    );
  } else if (plt === 'darwin') {
    candidates.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Chromium.app/Contents/MacOS/Chromium',
      '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser',
    );
  } else {
    for (const c of ['google-chrome', 'chromium', 'chromium-browser', 'microsoft-edge', 'brave-browser']) {
      try { candidates.push(execSync(`command -v ${c}`, { stdio: ['ignore','pipe','ignore'] }).toString().trim()); } catch {}
    }
  }
  return candidates.filter(Boolean).find(p => existsSync(p));
}

const httpJson = (port, path) => new Promise((res, rej) => {
  http.get({ host: '127.0.0.1', port, path }, r => {
    let d = ''; r.on('data', c => d += c); r.on('end', () => { try { res(JSON.parse(d)); } catch (e) { rej(e); } });
  }).on('error', rej);
});
const sleep = ms => new Promise(r => setTimeout(r, ms));

// minimal CDP client over the browser-level websocket, using flat sessions
function cdp(wsUrl) {
  const ws = new WebSocket(wsUrl);
  let id = 0; const pending = new Map(); const listeners = [];
  const ready = new Promise((res, rej) => { ws.onopen = () => res(); ws.onerror = e => rej(new Error('ws error')); });
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.id && pending.has(m.id)) { const { resolve, reject } = pending.get(m.id); pending.delete(m.id); m.error ? reject(new Error(m.error.message)) : resolve(m.result); }
    else if (m.method) listeners.forEach(fn => fn(m));
  };
  const send = (method, params = {}, sessionId) => ready.then(() => new Promise((resolve, reject) => {
    const mid = ++id; pending.set(mid, { resolve, reject });
    ws.send(JSON.stringify({ id: mid, method, params, sessionId }));
  }));
  return { send, on: fn => listeners.push(fn), close: () => ws.close(), ready };
}

// decode one MHTML part body by its transfer encoding
function decodePart(body, enc) {
  enc = (enc || '').toLowerCase();
  if (enc.includes('base64')) return Buffer.from(body.replace(/\s+/g, ''), 'base64').toString('utf8');
  if (enc.includes('quoted-printable'))
    return body.replace(/=\r?\n/g, '').replace(/=([0-9A-Fa-f]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
  return body;
}

// pull the artifact HTML out of an MHTML snapshot: prefer the frame served from
// the sandbox host; else the largest text/html part that isn't the claude shell.
function extractArtifact(mhtml) {
  const boundary = (mhtml.match(/boundary="([^"]+)"/) || [])[1];
  if (!boundary) return null;
  const parts = mhtml.split('--' + boundary).slice(1, -1);
  const htmlParts = [];
  for (const raw of parts) {
    const sep = raw.indexOf('\r\n\r\n') >= 0 ? '\r\n\r\n' : '\n\n';
    const i = raw.indexOf(sep); if (i < 0) continue;
    const head = raw.slice(0, i); const body = raw.slice(i + sep.length);
    if (!/content-type:\s*text\/html/i.test(head)) continue;
    const loc = (head.match(/content-location:\s*(\S+)/i) || [])[1] || '';
    const enc = (head.match(/content-transfer-encoding:\s*(\S+)/i) || [])[1] || '';
    htmlParts.push({ loc, html: decodePart(body, enc) });
  }
  if (!htmlParts.length) return null;
  const sandbox = htmlParts.find(p => /claudeusercontent\.com|livepreview\.claude/.test(p.loc));
  if (sandbox) return sandbox.html;
  const notShell = htmlParts.filter(p => !/^https?:\/\/claude\.ai/.test(p.loc));
  return (notShell.length ? notShell : htmlParts).sort((a, b) => b.html.length - a.html.length)[0].html;
}

(async () => {
  const bin = findBrowser();
  if (!bin) {
    console.error('error: no Chromium-family browser found (looked for Edge, Chrome, Chromium, Brave).\n' +
      'Fix: download the artifact (its download/copy control) and pass the .html file to the skill instead.');
    process.exit(2);
  }
  const port = 9200 + Math.floor((Date.now ? 0 : 0)); // fixed-ish; DevTools picks the actual one below
  const userDir = mkdtempSync(join(tmpdir(), 'ely-artifact-'));
  const proc = spawn(bin, [
    '--headless=new', '--disable-gpu', '--no-first-run', '--no-default-browser-check',
    '--remote-debugging-port=0', `--user-data-dir=${userDir}`, 'about:blank',
  ], { stdio: ['ignore', 'ignore', 'pipe'] });

  // Chrome prints "DevTools listening on ws://127.0.0.1:<port>/..." to stderr
  const wsBrowser = await new Promise((resolve, reject) => {
    let buf = ''; const to = setTimeout(() => reject(new Error('browser did not expose DevTools in time')), 15000);
    proc.stderr.on('data', d => {
      buf += d.toString();
      const m = buf.match(/ws:\/\/127\.0\.0\.1:\d+\/devtools\/browser\/[a-f0-9-]+/);
      if (m) { clearTimeout(to); resolve(m[0]); }
    });
    proc.on('exit', () => { clearTimeout(to); reject(new Error('browser exited early')); });
  }).catch(e => { console.error('error: ' + e.message); proc.kill(); process.exit(3); });

  const client = cdp(wsBrowser);
  try {
    const { targetId } = await client.send('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await client.send('Target.attachToTarget', { targetId, flatten: true });
    const S = (m, p) => client.send(m, p, sessionId);
    await S('Page.enable');
    const loaded = new Promise(res => { client.on(m => { if (m.method === 'Page.loadEventFired') res(); }); });
    await S('Page.navigate', { url });
    await Promise.race([loaded, sleep(20000)]);
    await sleep(5000); // let the artifact iframe hydrate
    const { data } = await S('Page.captureSnapshot', { format: 'mhtml' });
    const html = extractArtifact(data);
    proc.kill(); client.close();
    if (!html || html.length < 40) {
      console.error('error: could not extract artifact HTML from the page. It may not have finished loading, or the artifact host changed.\n' +
        'Fix: download the artifact and pass the .html file instead.');
      process.exit(4);
    }
    if (outFile) { writeFileSync(outFile, html); console.error(`wrote ${html.length} bytes -> ${outFile}`); }
    else process.stdout.write(html);
    process.exit(0);
  } catch (e) {
    console.error('error: ' + e.message + '\nFix: download the artifact and pass the .html file instead.');
    try { proc.kill(); } catch {}
    process.exit(3);
  }
})();
